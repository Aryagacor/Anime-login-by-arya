MUSIC PLAYER | BY ARYA
Fitur: login, daftar, lupa password, pemutar file audio lokal, playlist, play/pause, next/previous, shuffle, repeat.
Tema login ungu neon, halaman daftar merah neon.

BUILD:
1. Upload seluruh isi folder proyek ini ke repository GitHub baru (branch main).
2. Pastikan .github/workflows/build-apk.yml ikut di-upload.
3. Buka Actions > Build APK > Run workflow.
4. Setelah hijau, unduh artifact ANIME-LOGIN-BY-ARYA-APK dan ekstrak untuk mendapatkan app-debug.apk.

Musik: pilih file audio dari HP melalui tombol PILIH MUSIK DARI HP.
Akun tersimpan lokal di perangkat. Lupa password tidak menggunakan email/server, sehingga bukan pemulihan akun terverifikasi.
Catatan: versi ini memutar musik selama aplikasi aktif. Pemutaran layar mati/background yang andal membutuhkan implementasi layanan media Android native tambahan.
