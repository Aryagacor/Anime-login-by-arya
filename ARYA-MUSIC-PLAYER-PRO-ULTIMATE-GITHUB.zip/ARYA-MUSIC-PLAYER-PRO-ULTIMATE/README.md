# ARYA MUSIC PLAYER PRO — Android project

## Build APK with GitHub from Android phone
1. Create a GitHub repository named `arya-music-player-pro`.
2. Upload **all contents of this ZIP** to the repository root (including the hidden `.github` folder).
3. Open the repository's **Actions** tab.
4. Choose **Build ARYA MUSIC PLAYER PRO APK** and tap **Run workflow** (or push to main/master).
5. When the run is green, open the run → **Artifacts** → download `ARYA-MUSIC-PLAYER-PRO-APK`.
6. Extract the artifact ZIP; install `app-debug.apk` on Android.

## Notes
- This package wraps the existing ARYA Music Player HTML in Android WebView and includes a custom purple music launcher icon.
- Local music selection is wired through Android's file picker.
- Login/register in the HTML is local/demo authentication, not a secure online account system.
- Some Android-specific features such as persistent lock-screen controls and guaranteed background playback need a native media service and are not provided by this WebView wrapper.
- The current HTML already contains the core player controls, playlist/favorites/history, lyrics input, sleep timer, shuffle/repeat, and visualizers. Check the app on-device for device/WebView-dependent behavior.
